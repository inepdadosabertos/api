'use strict';

var express = require('express');
var http = require('http');
var path = require('path');
var fs = require('fs');
var querystring = require('querystring');


var app = express();


var RIAK_HOST = "54.207.108.144";
var RIAK_PORT = 8098;
var ORIGINAL_RIAK_URL = "http://" + RIAK_HOST + ":" + RIAK_PORT;
var RIAK_ITEM = "riak";
var RIAK_BUCKETS = "buckets";
var RIAK_MAPREDUCE = "mapred";
var RIAK_INDEX = "index";
var V1_IDEB_MUNICIPIO = "ideb_municipio";
var V1_IDEB_ESCOLA = "ideb_escola";



// configuration
try {
  var configJSON = fs.readFileSync(__dirname + "/config.json");
  var config = JSON.parse(configJSON.toString());
} catch (e) {
  console.error("File config.json not found or is invalid: " + e.message);
  process.exit(1);
}




var sdk_version = '0.0.1';
var user_agent = 'dadosabertosinep/rest-nodejs ' + sdk_version + ' (node ' + process.version + '-' + process.arch + '-' + process.platform  + ')';
var default_options = {
	'schema': 'http',
	'host': RIAK_HOST,
	'port': RIAK_PORT,
	'headers': {}
};






function executeHttp(http_method, path, data, http_options, cb) {
	if (typeof http_options === "function") {
		cb = http_options;
		http_options = null;
	}
	//if (!http_options) {
	//var http_options = default_options;
	//} else {
	//	http_options = copy_missing(http_options, default_options);
	//}

	function retry_invoke() {
		invoke(http_method, path, data, default_options, cb);
	}

	//if (http_options.correlation_id) {
	//	http_options.headers['Paypal-Application-Correlation-Id'] = http_options.correlation_id;
	//}

	invoke(http_method, path, data, default_options, function (error, response) {
		if (error && error.httpStatusCode === 401 && http_options.client_id && http_options.headers.Authorization) {
			http_options.headers.Authorization = null;
			update_token(http_options, cb, retry_invoke);
		} else {
			cb(error, response);
		}
	});
}


function invoke(http_method, path, data, http_options_param, cb) {
	console.log(http_options_param);

	var client = (http_options_param.schema === 'http') ? http : https;

	var request_data = data;

	if (http_method === 'GET') {
		if (typeof request_data !== 'string') {
			request_data = querystring.stringify(request_data);
		}
		if (request_data) {
			path = path + "?" + request_data;
			request_data = "";
		}
	} else if (typeof request_data !== 'string') {
		request_data = JSON.stringify(request_data);
	}

	var http_options = {};

	if (http_options_param) {

		http_options = JSON.parse(JSON.stringify(http_options_param));

		if (!http_options.headers) {
			http_options.headers = {};
		}
		http_options.path = path;
		http_options.method = http_method;
		if (request_data) {
			http_options.headers['Content-Length'] = Buffer.byteLength(request_data, 'utf-8');
		}

		if (!http_options.headers.Accept) {
			http_options.headers.Accept = 'application/json';
		}

		if (!http_options.headers['Content-Type']) {
			http_options.headers['Content-Type'] = 'application/json';
		}

		// if (http_method === 'POST' && !http_options.headers['PayPal-Request-Id']) {
		// 	http_options.headers['PayPal-Request-Id'] = uuid.v4();
		// }

		http_options.headers['User-Agent'] = user_agent;
	}

	var req = client.request(http_options);

	req.on('error', function (e) {
		console.log('problem with request: ' + e.message);
		cb(e, null);
	});

	req.on('response', function (res) {
		var response = '';
		res.setEncoding('utf8');

		res.on('data', function (chunk) {
			response += chunk;
		});

		res.on('end', function () {
			var err = null;

			response.httpStatusCode = res.statusCode;

			try {

				if (res.headers['content-type'] === "application/json") {
					response = JSON.parse(response);
				}

			} catch (e) {
				err = new Error('Invalid JSON Response Received');
				err.error = {
					name: 'Invalid JSON Response Received, JSON Parse Error'
				};
				err.response = response;
				err.httpStatusCode = res.statusCode;
				response = null;
			}

			if (!err && (res.statusCode < 200 || res.statusCode >= 300)) {
				err = new Error('Response Status : ' + res.statusCode);
				err.response = response;
				err.httpStatusCode = res.statusCode;
				response = null;
			}
			cb(err, response);
		});
	});

	if (request_data) {
		req.write(request_data);
	}
	req.end();
}





















function get_riak_by_index(url, cb) {
	executeHttp('GET', url.join("/"), null, null, cb)

}
function post_riak_mapreduce(url, items, bucket, cb) {

	var mapreduce = {
		"inputs": items.map(function(y){ return [bucket, y]; }),
		"query": [{
			"map": {
				"language": "javascript",
				"source": "function(value){ return Riak.mapValuesJson(value); }",
				"keep": true
			}
		}]
	};

	console.log("MAPREDUCE_DATA", mapreduce.inputs);

	executeHttp('POST', url.join("/"), mapreduce, null, cb);

	//return url + JSON.stringify(mapreduce);
}






/*

	executeHttp('GET', "/riak/ideb_escola/43101895", null, null, function(error, response){

		console.log("baixou /riak/ideb_escola/43101895");
		var result_list = response.codigo_escola;
		console.log(result_list);


	});




	executeHttp('GET', "/buckets/ideb_escola/index/uf_bin/ES", null, null, function(error, response){

		console.log("baixou /buckets/ideb_escola/index/uf_bin/ES");
		console.log(JSON.stringify(response));
		console.log();
		console.log(error);
		console.log();
		console.log();

	});

*/




function show_home(req, res) {
	res.sendfile(__dirname + '/template/index.html');
}

function redirect_github(req, res) {
	res.redirect("https://github.com/inepdadosabertos/api/");
}


//OK
function v1_ideb_escolas(req, res) {
	/*
		/ideb/escolas.{json|csv}
			uf=[sigla]
			codigo_municipio=[cod_municipio]
			rede=[municipal|estadual|federal|publica]
	*/
	var format = req.param("format");
	var uf = req.query.uf;
	var codigo_municipio = req.query.codigo_municipio;
	var rede = req.query.rede;

	var result = [];


	//new_escola.add_index('uf_bin', item['uf'])
	//new_escola.add_index('codigo_municipio_bin', item['codigo_municipio'])
	//new_escola.add_index('rede_bin', item['rede'])
	//new_escola.add_index('uf_rede_bin', "%s_%s" % (item['uf'], item['rede']))
	//new_escola.add_index('codigo_municipio_rede_bin', "%s_%s" % (item['codigo_municipio'], item['rede']))

	//http://127.0.0.1:8098/buckets/ideb_escola/index/rede_bin/municipal/
	//http://127.0.0.1:8098/buckets/ideb_municipio/index/uf_bin/MG/



	//http://54.207.108.144:8098/buckets/ideb_escola/index/uf_rede_bin/municipal/
	//http://54.207.108.144:8098/buckets/ideb_escola/index/codigo_municipio_rede_bin/1234_municipal/
	//http://54.207.108.144:8098/buckets/ideb_escola/index/rede_bin/municipal/
	//http://54.207.108.144:8098/buckets/ideb_escola/index/uf_bin/MG/



	if (!uf && !codigo_municipio && !rede)
		return res.send(500, "Precisa informar uf ou codigo_municipio ou rede");
		url += V1_IDEB_ESCOLA;


	if (uf && rede) {

		var url = [];
		//url.push(ORIGINAL_RIAK_URL);
		url.push("");
		url.push(RIAK_BUCKETS);
		url.push(V1_IDEB_ESCOLA);
		url.push(RIAK_INDEX);
		url.push("uf_rede_bin");
		url.push([uf,rede].join("_"));



	} else if (codigo_municipio && rede) {

		var url = [];
		//url.push(ORIGINAL_RIAK_URL);
		url.push("");
		url.push(RIAK_BUCKETS);
		url.push(V1_IDEB_ESCOLA);
		url.push(RIAK_INDEX);
		url.push("codigo_municipio_rede_bin");
		url.push([codigo_municipio,rede].join("_"));


	} else if (rede) {

		var url = [];
		//url.push(ORIGINAL_RIAK_URL);
		url.push("");
		url.push(RIAK_BUCKETS);
		url.push(V1_IDEB_ESCOLA);
		url.push(RIAK_INDEX);
		url.push("rede_bin");
		url.push(rede);


	} else if (uf) {

		var url = [];
		//url.push(ORIGINAL_RIAK_URL);
		url.push("");
		url.push(RIAK_BUCKETS);
		url.push(V1_IDEB_ESCOLA);
		url.push(RIAK_INDEX);
		url.push("uf_bin");
		url.push(uf);



	} else if (codigo_municipio) {

		var url = [];
		//url.push(ORIGINAL_RIAK_URL);
		url.push("");
		url.push(RIAK_BUCKETS);
		url.push(V1_IDEB_ESCOLA);
		url.push(RIAK_INDEX);
		url.push("codigo_municipio_bin");
		url.push(codigo_municipio);

	}


	// fazer consulta da URL inicial, pegar array do resultado e calcular mapreduce
	get_riak_by_index(url, function(error, response){
		var url = [];
		url.push("");
		url.push(RIAK_MAPREDUCE);

		// consulta com mapreduce
		post_riak_mapreduce(url, response.keys, V1_IDEB_ESCOLA, function(error, response){
			//console.log("MAPREDUCE RETURN", response);
			//console.log("MAPREDUCE ERROR", error);
			//res.send(JSON.stringify(response));
			res.send(response);

		});

	});

}

//OK
function v1_ideb_municipios(req, res) {
	/*
		/ideb.{json|csv}
			uf=[sigla]
			REMOVIDO: rede=[municipal|estadual|federal|publica]
	*/


	var format = req.param("format");
	var uf = req.query.uf;
	//var rede = req.query.rede; //removido por nao haver remocao de campo agora

	var result = [];
	result.push("rede_bin");

	var url = [];
	url.push("");
	url.push(RIAK_BUCKETS);
	url.push(V1_IDEB_MUNICIPIO);
	url.push(RIAK_INDEX);
	url.push("uf_bin");
	url.push(uf);

	result.push("consulta municipios da UF");
	result.push(url.join("/"));


	// fazer consulta da URL inicial, pegar array do resultado e calcular mapreduce
	get_riak_by_index(url, function(error, response){
		var url = [];
		url.push("");
		url.push(RIAK_MAPREDUCE);

		// consulta com mapreduce
		post_riak_mapreduce(url, response.keys, V1_IDEB_MUNICIPIO, function(error, response){
			res.send(response);

		});

	});

}


//OK
function v1_ideb_escola(req, res) {
	/*
		/ideb/escola/[código_escola].{json|csv}
	*/
	var format = req.param("format");
	var codigo_escola = req.param("codigo_escola");


	var url = [];
	url.push(ORIGINAL_RIAK_URL);
	url.push(RIAK_ITEM);
	url.push(V1_IDEB_ESCOLA);
	url.push(codigo_escola);


	get_riak_by_index(url, function(error, response){
		//res.send(JSON.stringify(response));
		res.send(response);
	});


}
function v1_ideb_municipios_rede(req, res) {
	/*
		/ideb/uf/[uf].{json|csv}
			rede=[municipal|estadual|federal|publica]
	*/

	//TODO: implementar
	return res.send(500, "NAO IMPLEMENTADO"); 
}
function v1_ideb_municipio(req, res) {
	/*
		/ideb/municipio/[código_municipio].{json|csv}
	*/

	//TODO: implementar
	return res.send(500, "NAO IMPLEMENTADO"); 
}




// all environments
app.set('port', process.env.PORT || config.port);
app.use(express.static(path.join(__dirname, 'public')));



// routes
app.get("/", show_home);
app.get("/v1", redirect_github);
app.get("/v1/ideb/escolas.:format", v1_ideb_escolas); //lista de escolas com filtros
app.get("/v1/ideb.:format", v1_ideb_municipios); //resumo de dados por municipio
app.get("/v1/ideb/escola/:codigo_escola.:format", v1_ideb_escola); //retorna uma escola específica

//NAO IMPLEMENTADO
app.get("/v1/ideb/uf/:uf.:format", v1_ideb_municipios_rede); //(FUTURO) retorna resumo agrupado de uma UF específica
app.get("/v1/ideb/municipio/:codigo_municipio.:format", v1_ideb_municipio); //(FUTURO) retorna resultado agrupado de um município específico







http.createServer(app).listen(app.get('port'), function () {
  console.log('Express server listening on port ' + app.get('port'));
});


//var routes = require('./routes');
